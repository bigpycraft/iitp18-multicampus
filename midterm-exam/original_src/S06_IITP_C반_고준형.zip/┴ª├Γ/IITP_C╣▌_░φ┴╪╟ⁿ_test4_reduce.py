from functools import *

animals = ["cat", "cat", "cat", "sheep", "sheep", "duck", "duck", "duck", "duck"]
dic1 = {'car':1, 'tree':2}
print(dic1)
print(dic1['car'])

print('--------')

# def draw_histogram(b):
# #     count = {}
# #     for sth in b:
# #         input = sth
# #         print(type(input))
# #         print(count['cat'])
# #         if bool(count[input]) == False:
# #             count[input] = 1
# #         print(count)
# # print(draw_histogram(animals))
# #
# # # reduce(draw_histogram, data)

# count = {}
#
# def draw_histogram(a, b):
#     print(a, b)
#     print(count.keys())
#     print(a in count.keys())
#     print(count)
#     print(bool(count))
#     print(a == b)
#     print(count.items())
#
# # dict 안에 해당 값이 없을 경우 만들어주고, 있으면 통과
#     if a in count.keys():
#         pass
#     else:
#         count[a] = 1
#     if b in count.keys():
#         pass
#     else:
#         count[b] = 1
#
# # dict 안에 해당 값이 있음
#     if a == b:
#         count[a] += 1
#
#     else:
#         count[b] = count[b] + 1
#
#     print('count:', count, '\n---')
#
#
# result = reduce(draw_histogram, animals)
# print(result)

count = {}

def draw_histogram(a, b):
    print(a, b)

    if bool(count) == False:
        print('empty dict:', count)
        count[a] = 1
    else:
        print('dict exists')
        pass

    if b in count.keys():
        print('plus')
        count[b] += 1
    else:
        print('make one')
        count[b] = 1

    print('count:', count, '\n', '-'*40)
    return count

result = reduce(draw_histogram, animals)
print('result:', result)
for key in result.keys():
    print(key, '\t', '='*result[key])