# 실습1. 2^1000의 각 자리수를 모두 더하면 얼마입니까?

# 각 자리 숫자를 분리해 리스트화
number = 2 ** 1000
list_number = list(str(number))
print(list_number)

# 덧셈 함수 생성
def sum(a, b):
    return int(a) + int(b)

# reduce 적용
from functools import *
result = reduce(sum, list_number)
print('2^1000의 각 자리수의 합:', result)