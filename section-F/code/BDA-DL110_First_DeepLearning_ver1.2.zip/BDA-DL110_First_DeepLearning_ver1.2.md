
# Industry 4.0 의 중심, AI - ML&DL

<div align='right'><font size=2 color='gray'>Machine Learning & Deep Learning with TensorFlow @ <font color='blue'><a href='https://www.facebook.com/jskim.kr'>FB / jskim.kr</a></font>, 김진수</font></div>
<hr>

# Sect1. First Deep Learning


```python
from images import bigpycraft_dl as bpc
from IPython.display import Image 
from tqdm import tqdm_notebook
```

### AI, ML, DL 의 관계 
> 인공지능 > 머신러닝 > 딥러닝


```python
Image(bpc.DL01_IMG_101)
```




![jpeg](output_5_0.jpeg)




```python
Image(bpc.DL01_IMG_102, width=600)
```




![png](output_6_0.png)




```python
Image(bpc.DL01_IMG_103)
```




![jpeg](output_7_0.jpeg)



### 딥러닝 개요
>  
* 미지의 일을 예측하는 힘
* 머신러닝 : 기존 데이터를 이용해 아직 일어나지 않은 미지의 일을 예측하기 위해 만들어진 기법
* 학습(training) : 데이터가 입력되고 패턴이 분석되는 과정


```python
Image(bpc.DL01_IMG_110, width=400)
```




![png](output_9_0.png)




```python
Image(bpc.DL01_IMG_112, width=600)
```




![jpeg](output_10_0.jpeg)




```python
! python --version
```

    Python 3.6.3 :: Anaconda custom (64-bit)
    


```python
import tensorflow as tf

tf.__version__
```

    C:\Python\Anaconda3-50\lib\site-packages\h5py\__init__.py:34: FutureWarning: Conversion of the second argument of issubdtype from `float` to `np.floating` is deprecated. In future, it will be treated as `np.float64 == np.dtype(float).type`.
      from ._conv import register_converters as _register_converters
    




    '1.8.0'




```python
! pip install keras
```

    Requirement already satisfied: keras in c:\python\anaconda3-50\lib\site-packages (2.2.4)
    Requirement already satisfied: keras-applications>=1.0.6 in c:\python\anaconda3-50\lib\site-packages (from keras) (1.0.6)
    Requirement already satisfied: six>=1.9.0 in c:\python\anaconda3-50\lib\site-packages (from keras) (1.11.0)
    Requirement already satisfied: pyyaml in c:\python\anaconda3-50\lib\site-packages (from keras) (3.12)
    Requirement already satisfied: keras-preprocessing>=1.0.5 in c:\python\anaconda3-50\lib\site-packages (from keras) (1.0.5)
    Requirement already satisfied: h5py in c:\python\anaconda3-50\lib\site-packages (from keras) (2.7.0)
    Requirement already satisfied: numpy>=1.9.1 in c:\python\anaconda3-50\lib\site-packages (from keras) (1.14.2)
    Requirement already satisfied: scipy>=0.14 in c:\python\anaconda3-50\lib\site-packages (from keras) (0.19.1)
    

<hr>
### 01_My_First_Deeplearning.py
> 폐암 수술 환자의 생존을 예측하기 실습 (흉부외과)

``` python

# -*- coding: utf-8 -*-
# 코드 내부에 한글을 사용가능 하게 해주는 부분입니다.

# 딥러닝을 구동하는 데 필요한 케라스 함수를 불러옵니다.
from keras.models import Sequential
from keras.layers import Dense

# 필요한 라이브러리를 불러옵니다.
import numpy
import tensorflow as tf

# 실행할 때마다 같은 결과를 출력하기 위해 설정하는 부분입니다.
seed = 0
numpy.random.seed(seed)
tf.set_random_seed(seed)

# 준비된 수술 환자 데이터를 불러들입니다.
Data_set = numpy.loadtxt("../dataset/ThoraricSurgery.csv", delimiter=",")

# 환자의 기록과 수술 결과를 X와 Y로 구분하여 저장합니다.
X = Data_set[:,0:17]
Y = Data_set[:,17]

# 딥러닝 구조를 결정합니다(모델을 설정하고 실행하는 부분입니다).
model = Sequential()
model.add(Dense(30, input_dim=17, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

# 딥러닝을 실행합니다.
model.compile(loss='mean_squared_error', optimizer='adam', metrics=['accuracy'])
model.fit(X, Y, epochs=30, batch_size=10)

# 결과를 출력합니다.
print("\n Accuracy: %.4f" % (model.evaluate(X, Y)[1]))



```
<br/>
<hr>


```python
# 딥러닝을 구동하는 데 필요한 케라스 함수를 불러옵니다.
from keras.models import Sequential
from keras.layers import Dense

# 필요한 라이브러리를 불러옵니다.
import numpy
import tensorflow as tf
```

    Using TensorFlow backend.
    


```python
# 실행할 때마다 같은 결과를 출력하기 위해 설정하는 부분입니다.
seed = 0
numpy.random.seed(seed)
tf.set_random_seed(seed)

# 준비된 수술 환자 데이터를 불러들입니다.
Data_set = numpy.loadtxt("./dataset/ThoraricSurgery.csv", delimiter=",")
Data_set
```




    array([[293.  ,   1.  ,   3.8 , ...,   0.  ,  62.  ,   0.  ],
           [  1.  ,   2.  ,   2.88, ...,   0.  ,  60.  ,   0.  ],
           [  8.  ,   2.  ,   3.19, ...,   0.  ,  66.  ,   1.  ],
           ...,
           [406.  ,   6.  ,   5.36, ...,   0.  ,  62.  ,   0.  ],
           [ 25.  ,   8.  ,   4.32, ...,   0.  ,  58.  ,   1.  ],
           [447.  ,   8.  ,   5.2 , ...,   0.  ,  49.  ,   0.  ]])




```python
# 환자의 기록과 수술 결과를 X와 Y로 구분하여 저장합니다.
X = Data_set[:, 0:17]    # 속성(attribute) : 종양의 유형, 폐활량, 호흡곤란여부, 고통정도, 기침, 흡연, 천식여부 등 
Y = Data_set[:, 17]      # 클래스(class) : 마지막 18번째 정보는 수술후 생존결과
X, Y
```




    (array([[293.  ,   1.  ,   3.8 , ...,   1.  ,   0.  ,  62.  ],
            [  1.  ,   2.  ,   2.88, ...,   1.  ,   0.  ,  60.  ],
            [  8.  ,   2.  ,   3.19, ...,   1.  ,   0.  ,  66.  ],
            ...,
            [406.  ,   6.  ,   5.36, ...,   0.  ,   0.  ,  62.  ],
            [ 25.  ,   8.  ,   4.32, ...,   0.  ,   0.  ,  58.  ],
            [447.  ,   8.  ,   5.2 , ...,   0.  ,   0.  ,  49.  ]]),
     array([0., 0., 1., 1., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0., 1., 0., 0.,
            0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 1., 1., 0., 0., 0.,
            0., 0., 1., 0., 0., 1., 0., 0., 0., 1., 0., 1., 0., 0., 1., 0., 0.,
            0., 0., 0., 0., 0., 1., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
            0., 0., 0., 0., 1., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
            0., 1., 0., 0., 0., 0., 0., 0., 0., 1., 0., 1., 0., 0., 0., 0., 0.,
            0., 0., 0., 0., 0., 0., 1., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0.,
            0., 0., 0., 0., 1., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0., 0.,
            0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 1.,
            0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 1., 0., 0., 0., 0., 0.,
            0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 1., 0., 1., 0., 0., 0., 0.,
            0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 1., 1., 0., 0., 0., 0.,
            0., 0., 0., 0., 0., 0., 1., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0.,
            1., 0., 1., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0.,
            0., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0.,
            0., 1., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
            0., 0., 0., 0., 0., 1., 1., 0., 0., 0., 0., 1., 0., 0., 1., 0., 0.,
            0., 0., 1., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0., 0.,
            0., 0., 0., 1., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0., 1., 0.,
            0., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
            0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
            0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0.,
            0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0.,
            0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 0.,
            0., 1., 0., 1., 0., 0., 0., 1., 1., 0., 0., 0., 0., 0., 0., 0., 0.,
            0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
            0., 1., 0., 0., 0., 0., 1., 0., 0., 1., 1., 0., 0., 1., 1., 0., 1.,
            0., 0., 1., 1., 0., 0., 0., 0., 0., 1., 0.]))



<hr>
### keras.engine.sequential.Sequential API

### - 딥러닝 구조를 결정

``` python
Init signature: Dense(units, activation=None, use_bias=True, kernel_initializer='glorot_uniform', bias_initializer='zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None, **kwargs)
Docstring:     
Just your regular densely-connected NN layer.
Arguments:
    units: Positive integer, dimensionality of the output space.
    activation: Activation function to use
        (see [activations](../activations.md)).
        If you don't specify anything, no activation is applied
        (ie. "linear" activation: `a(x) = x`).
        
Signature: model.add(layer)
Docstring:
Adds a layer instance on top of the layer stack.
```

### - 딥러닝 실행
``` python
Signature: model.compile(optimizer, loss=None, metrics=None, loss_weights=None, sample_weight_mode=None, weighted_metrics=None, target_tensors=None, **kwargs)
Docstring:
Configures the model for training.


Signature: model.fit(x=None, y=None, batch_size=None, epochs=1, verbose=1, callbacks=None, validation_split=0.0, validation_data=None, shuffle=True, class_weight=None, sample_weight=None, initial_epoch=0, steps_per_epoch=None, validation_steps=None, **kwargs)
Docstring:
Trains the model for a given number of epochs (iterations on a dataset).
```


### - 참조, Params
>  
- activation : 다음층으로 어떻게 값을 넘길지 결정하는 부분   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; eg. relu, sigmoid
- loss : 한번 신경망이 실행될 때마다 오차 값을 추적하는 함수 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; cf. like cost 
- optimizer : 오차를 어떻게 줄여 나갈지 정하는 함수


```python
# 딥러닝 구조를 결정합니다(모델을 설정하고 실행하는 부분입니다).
model = Sequential()
model.add(Dense(30, input_dim=17, activation='relu'))
model.add(Dense(1, activation='sigmoid'))
type(model)
```




    keras.engine.sequential.Sequential




```python
# 딥러닝을 실행합니다.
model.compile(loss='mean_squared_error', optimizer='adam', metrics=['accuracy'])
model.fit(X, Y, epochs=30, batch_size=10)
```

    Epoch 1/30
    470/470 [==============================] - ETA: 6s - loss: 1.0000 - acc: 0.0000e+0 - 0s 400us/step - loss: 0.6615 - acc: 0.3149
    Epoch 2/30
    470/470 [==============================] - ETA: 0s - loss: 0.0994 - acc: 0.900 - 0s 83us/step - loss: 0.1488 - acc: 0.8511
    Epoch 3/30
    470/470 [==============================] - ETA: 0s - loss: 0.1000 - acc: 0.900 - 0s 83us/step - loss: 0.1488 - acc: 0.8511
    Epoch 4/30
    470/470 [==============================] - ETA: 0s - loss: 0.3980 - acc: 0.600 - 0s 84us/step - loss: 0.1488 - acc: 0.8511
    Epoch 5/30
    470/470 [==============================] - ETA: 0s - loss: 2.2078e-12 - acc: 1.000 - 0s 85us/step - loss: 0.1488 - acc: 0.8511
    Epoch 6/30
    470/470 [==============================] - ETA: 0s - loss: 0.2000 - acc: 0.800 - 0s 75us/step - loss: 0.1487 - acc: 0.8511
    Epoch 7/30
    470/470 [==============================] - ETA: 0s - loss: 0.1000 - acc: 0.900 - 0s 81us/step - loss: 0.1487 - acc: 0.8511
    Epoch 8/30
    470/470 [==============================] - ETA: 0s - loss: 0.2000 - acc: 0.800 - 0s 81us/step - loss: 0.1487 - acc: 0.8511
    Epoch 9/30
    470/470 [==============================] - ETA: 0s - loss: 5.0395e-07 - acc: 1.000 - 0s 90us/step - loss: 0.1487 - acc: 0.8511
    Epoch 10/30
    470/470 [==============================] - ETA: 0s - loss: 0.1000 - acc: 0.900 - 0s 92us/step - loss: 0.1486 - acc: 0.8511
    Epoch 11/30
    470/470 [==============================] - ETA: 0s - loss: 0.2000 - acc: 0.800 - 0s 97us/step - loss: 0.1498 - acc: 0.8447
    Epoch 12/30
    470/470 [==============================] - ETA: 0s - loss: 0.2000 - acc: 0.800 - 0s 86us/step - loss: 0.1486 - acc: 0.8511
    Epoch 13/30
    470/470 [==============================] - ETA: 0s - loss: 0.1000 - acc: 0.900 - 0s 90us/step - loss: 0.1485 - acc: 0.8511
    Epoch 14/30
    470/470 [==============================] - ETA: 0s - loss: 0.2000 - acc: 0.800 - 0s 79us/step - loss: 0.1483 - acc: 0.8511
    Epoch 15/30
    470/470 [==============================] - ETA: 0s - loss: 0.1000 - acc: 0.900 - 0s 73us/step - loss: 0.1485 - acc: 0.8511
    Epoch 16/30
    470/470 [==============================] - ETA: 0s - loss: 0.1015 - acc: 0.900 - 0s 94us/step - loss: 0.1490 - acc: 0.8447
    Epoch 17/30
    470/470 [==============================] - ETA: 0s - loss: 1.9164e-15 - acc: 1.000 - 0s 81us/step - loss: 0.1479 - acc: 0.8489
    Epoch 18/30
    470/470 [==============================] - ETA: 0s - loss: 0.2000 - acc: 0.800 - 0s 81us/step - loss: 0.1482 - acc: 0.8468
    Epoch 19/30
    470/470 [==============================] - ETA: 0s - loss: 0.3000 - acc: 0.700 - 0s 88us/step - loss: 0.1476 - acc: 0.8511
    Epoch 20/30
    470/470 [==============================] - ETA: 0s - loss: 0.1000 - acc: 0.900 - 0s 83us/step - loss: 0.1480 - acc: 0.8511
    Epoch 21/30
    470/470 [==============================] - ETA: 0s - loss: 0.2997 - acc: 0.700 - 0s 83us/step - loss: 0.1475 - acc: 0.8511
    Epoch 22/30
    470/470 [==============================] - ETA: 0s - loss: 0.1000 - acc: 0.900 - 0s 83us/step - loss: 0.1469 - acc: 0.8511
    Epoch 23/30
    470/470 [==============================] - ETA: 0s - loss: 0.1000 - acc: 0.900 - 0s 87us/step - loss: 0.1466 - acc: 0.8511
    Epoch 24/30
    470/470 [==============================] - ETA: 0s - loss: 0.2082 - acc: 0.800 - 0s 77us/step - loss: 0.1475 - acc: 0.8489
    Epoch 25/30
    470/470 [==============================] - ETA: 0s - loss: 0.2996 - acc: 0.700 - 0s 85us/step - loss: 0.1470 - acc: 0.8511
    Epoch 26/30
    470/470 [==============================] - ETA: 0s - loss: 2.3218e-05 - acc: 1.000 - 0s 80us/step - loss: 0.1466 - acc: 0.8511
    Epoch 27/30
    470/470 [==============================] - ETA: 0s - loss: 0.3000 - acc: 0.700 - 0s 79us/step - loss: 0.1472 - acc: 0.8511
    Epoch 28/30
    470/470 [==============================] - ETA: 0s - loss: 0.2000 - acc: 0.800 - 0s 77us/step - loss: 0.1471 - acc: 0.8511
    Epoch 29/30
    470/470 [==============================] - ETA: 0s - loss: 0.1991 - acc: 0.800 - 0s 77us/step - loss: 0.1470 - acc: 0.8489
    Epoch 30/30
    470/470 [==============================] - ETA: 0s - loss: 8.3727e-07 - acc: 1.000 - 0s 76us/step - loss: 0.1461 - acc: 0.8532
    




    <keras.callbacks.History at 0x2e79c1bcdd8>




```python
# 결과를 출력합니다.
# print("Accuracy: %.4f" % (model.evaluate(X, Y)[1]))
accuracy = model.evaluate(X, Y)[1]
accuracy = float(accuracy)
```

    470/470 [==============================] - ETA:  - 0s 77us/step
    


```python
print("Accuracy: %.4f" % accuracy )
```

    Accuracy: 0.8511
    

<hr>
<marquee><font size=3 color='brown'>The BigpyCraft find the information to design valuable society with Technology & Craft.</font></marquee>
<div align='right'><font size=2 color='gray'> &lt; The End &gt; </font></div>
