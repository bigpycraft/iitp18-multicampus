# 실습3. 특정 기념일로부터 얼마나 경과되었는지 알려주는 함수
# - 경과일자가 1000일이 넘는 경우, 천 단위로 콤마(,)를 붙혀서 출력
# - 구현할 함수의 옵션:
# from datetime import datetime
# def getMemorialDay(year, month, day, mem_day='기념일', is_msg=True):
#     return remain_year, remain_month, remain_day
# - 출력형태
# > getMemorialDay(2014, 4, 15, '세월호침몰사고일')
# 오늘은 "세월호침몰사고일"로부터 1,658일 경과되었고, 달 수로는 55개우러재, 연 수로는 4년째 되었습니다.
# > _y, _m, elapsed_day = getMemoraialDay(2018, 12, 25, '크리스마스', False)
# '크리스마스까지는 %d일 남았습니다.' % -elapsed_day

# 작업 순서
# 세 자리마다 콤마(,) 넣기
# 세월호침몰사고일 입력
# 오늘날짜 입력
# 경과일 계산
# 경과일 표현

# 세 자리마다 콤마(,) 넣기
# 미완성
a = 1234567
a = list(str(a))
print(a)

new_letter = []
# where = len(a) % 3
print(range(2))
for n in range(len(a)//3):
    where = len(a) % 3
    # print(n <= (len(a) / 3))
    where = where + 3**n
    a.insert(where, ',')
print(a)
    # print(slice)
#    a.insert(n, ',')
# print(a)
# a = str(a)
# print(a)

# 함수 설정
# 미완성
from datetime import date, datetime

def getMemorialDay(year, month, day, mem_day='기념일', is_msg=True):
    the_date = datetime(year, month, day)
    today = datetime.today()
    elapsed = today - the_date
    remain_day = elapsed.days()
    # remain_year = elapsed.years

    return remain_year, remain_month, remain_day
sewol = getMemorialDay(2018, 2, 3, '세월호침몰사고일')
print(sewol.remain_day)

# # 세월호침몰사고일 입력
# the_date = d(2018, 2, 3)
# print(the_date)
#
# # 오늘날짜 입력
# today = d.today()
# print(today)
# # 경과일 계산
# elapsed = today - the_date
# print(elapsed)
# print(elapsed.days)
# 경과일 표현