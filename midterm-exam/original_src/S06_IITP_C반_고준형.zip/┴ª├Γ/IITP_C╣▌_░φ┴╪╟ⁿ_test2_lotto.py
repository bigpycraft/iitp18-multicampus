# 실습2. 로또번호를 주문하는 클래스(Class Lotto)를 생성하시오.
# - 로또는 1~10까지 주문 가능
# - 6개의 숫자로 된 로또는 오름차순으로 정렬
# - 주문한 개수만큼의 일련번호를 달아 로또번호를 출력
# - OOP 기반으로 클래스에 메소드를 최대한 모듈화

# 작업 순서:
# 난수 발행해보기
# 클래스 로또 생성
# 메소드에서 난수 생성
# 로또 1장 발행해보기
# 로또 n장 주세요.를 input으로 받기
# n개의 인스턴스 생성하기
# 클래스 최적화

# 난수 발행해보기
import random as r
a = r.random()
print(a)
# 1~10 중 숫자 6개 선택
b = r.sample(range(1, 11), 6)
print(b)

# 클래스 로또 생성
# 초기 속성값 생성
class Lotto:
    def __init__(self, name):
        self.name = name

# 메소드 생성
    def do_lotto(self):
        try1 = r.sample(range(1, 11), 6)
        # print(try1)
        return try1

# 로또 1장 발행
l1 = Lotto('1otto1')
print('result:', l1.name, l1.do_lotto())

# 로또 입력기 생성
# validation
while True:
    key = input('로또 몇 장 드릴까요?')
    # key = '12a3'
    key2 = list(str(key))
    # print(key2)
    check_list = list('1234567890')
    # print(check_list)
    valid = 1
    for letter in key2:
        valid = valid * (letter in check_list)
    # print(valid)
    if valid == 1:
        break

# 주문 안내
print('로또', key, '장 주문하셨습니다.')

# 로또 n장 발행
key = int(key)
for n in range(key):
    n = n + 1
    l = Lotto(n)
    print('로또 %d:' % n, l.do_lotto())

# 클래스 최적화